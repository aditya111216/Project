import streamlit as st
import pandas as pd
import numpy as np
import pickle

st.set_page_config(page_title="Movie IMDb Rating Predictor", page_icon="🎬", layout="centered")

# Load model and encoders
with open("xgb_movie_model.pkl", "rb") as f:
    model = pickle.load(f)

with open("feature_columns.pkl", "rb") as f:
    feature_columns = pickle.load(f)

with open("label_encoders.pkl", "rb") as f:
    encoders = pickle.load(f)

# Helper: encode text → integer using saved LabelEncoder
def encode_value(column_name, value):
    le = encoders[column_name]
    return le.transform([value])[0]

# Helper: classify predicted score
def movie_category(score):
    if score >= 8:
        return "Excellent Movie 🌟"
    elif score >= 7:
        return "Good Movie 🎬"
    elif score >= 5:
        return "Average Movie 👍"
    return "Poor Movie 👎"

# Styling
st.markdown("""
<style>
.main-title {
    text-align: center;
    font-size: 36px;
    font-weight: bold;
    color: #5e2ca5;
    margin-bottom: 8px;
}
.sub-title {
    text-align: center;
    font-size: 18px;
    color: #444444;
    margin-bottom: 25px;
}
.result-box {
    background-color: #f3f7ff;
    border: 2px solid #d6e4ff;
    border-radius: 14px;
    padding: 18px;
    margin-top: 20px;
    text-align: center;
    font-size: 24px;
    font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

st.markdown('<div class="main-title">🎬 Movie IMDb Rating Predictor</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Predict IMDb score using your trained XGBoost model</div>', unsafe_allow_html=True)

st.subheader("Enter Movie Details")

# --- Categorical inputs (text dropdowns — type to search) ---
director_name    = st.selectbox("Director Name",    encoders["director_name"].classes_)
actor_1_name     = st.selectbox("Actor 1 Name",     encoders["actor_1_name"].classes_)
actor_2_name     = st.selectbox("Actor 2 Name",     encoders["actor_2_name"].classes_)
genres           = st.selectbox("Genres",           encoders["genres"].classes_)
country          = st.selectbox("Country",          encoders["country"].classes_)
content_rating   = st.selectbox("Content Rating",   encoders["content_rating"].classes_)

# --- Numeric inputs ---
num_critic_for_reviews    = st.number_input("Number of Critic Reviews",       min_value=0,    value=200)
duration                  = st.number_input("Duration (minutes)",             min_value=1,    value=120)
director_facebook_likes   = st.number_input("Director Facebook Likes",        min_value=0,    value=1000)
actor_3_facebook_likes    = st.number_input("Actor 3 Facebook Likes",         min_value=0,    value=500)
actor_1_facebook_likes    = st.number_input("Actor 1 Facebook Likes",         min_value=0,    value=15000)
gross                     = st.number_input("Gross ($)",                      min_value=0.0,  value=100000000.0)
num_voted_users           = st.number_input("Number of Voted Users",          min_value=0,    value=500000)
cast_total_facebook_likes = st.number_input("Cast Total Facebook Likes",      min_value=0,    value=20000)
num_user_for_reviews      = st.number_input("Number of User Reviews",         min_value=0,    value=1000)
budget                    = st.number_input("Budget ($)",                     min_value=0.0,  value=150000000.0)
title_year                = st.number_input("Title Year",                     min_value=1900, max_value=2100, value=2015)
actor_2_facebook_likes    = st.number_input("Actor 2 Facebook Likes",         min_value=0,    value=8000)
movie_facebook_likes      = st.number_input("Movie Facebook Likes",           min_value=0,    value=25000)

if st.button("Predict IMDb Score"):

    # Step 1: Label encode categorical columns (text → integer)
    director_encoded       = encode_value("director_name",   director_name)
    actor1_encoded         = encode_value("actor_1_name",    actor_1_name)
    actor2_encoded         = encode_value("actor_2_name",    actor_2_name)
    genres_encoded         = encode_value("genres",          genres)
    country_encoded        = encode_value("country",         country)
    content_rating_encoded = encode_value("content_rating",  content_rating)

    # Step 2: Apply log(x+1) transformation — MUST match training (Cell 38 in notebook)
    input_data = {
        "director_name":             np.log(director_encoded            + 1),
        "num_critic_for_reviews":    np.log(num_critic_for_reviews      + 1),
        "duration":                  np.log(duration                    + 1),
        "director_facebook_likes":   np.log(director_facebook_likes     + 1),
        "actor_3_facebook_likes":    np.log(actor_3_facebook_likes      + 1),
        "actor_2_name":              np.log(actor2_encoded              + 1),
        "actor_1_facebook_likes":    np.log(actor_1_facebook_likes      + 1),
        "gross":                     np.log(gross                       + 1),
        "genres":                    np.log(genres_encoded              + 1),
        "actor_1_name":              np.log(actor1_encoded              + 1),
        "num_voted_users":           np.log(num_voted_users             + 1),
        "cast_total_facebook_likes": np.log(cast_total_facebook_likes   + 1),
        "num_user_for_reviews":      np.log(num_user_for_reviews        + 1),
        "country":                   np.log(country_encoded             + 1),
        "content_rating":            np.log(content_rating_encoded      + 1),
        "budget":                    np.log(budget                      + 1),
        "title_year":                np.log(title_year                  + 1),
        "actor_2_facebook_likes":    np.log(actor_2_facebook_likes      + 1),
        "movie_facebook_likes":      np.log(movie_facebook_likes        + 1),
    }

    # Step 3: Build dataframe in correct column order
    input_df = pd.DataFrame([input_data])
    input_df = input_df[feature_columns]

    # Step 4: Predict — model output is log(imdb_score+1), reverse with expm1
    log_prediction = model.predict(input_df)[0]
    prediction = np.expm1(log_prediction)          # reverse of log(x+1)
    prediction = round(float(np.clip(prediction, 1.0, 10.0)), 2)

    st.markdown(
        f'<div class="result-box">Predicted IMDb Score: {prediction} / 10<br>{movie_category(prediction)}</div>',
        unsafe_allow_html=True
    )